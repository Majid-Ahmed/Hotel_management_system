/**
 * 
 */
/**
 * @author HP
 *
 */
module Java_project {
	requires java.sql;
}